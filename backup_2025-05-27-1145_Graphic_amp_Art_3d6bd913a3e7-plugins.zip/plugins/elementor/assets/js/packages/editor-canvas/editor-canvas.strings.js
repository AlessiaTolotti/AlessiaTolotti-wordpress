__(
			"To paste a link to this element, first remove the link from it's parent container.",
			'elementor'
		);
__( "To drag a link to this element, first remove the link from it's parent container.", 'elementor' );
__( 'Elements', 'elementor' );
__( 'Style Reset', 'elementor' );
__( 'Style Pasted', 'elementor' );